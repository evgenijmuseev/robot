<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Обучающие материалы / Добавление (редактирование) видео</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="addvideo-header">
                <div class="addvideo-text">
                    <h2 class="addvideo-text__pretitle">Обучающие материалы</h2>
                    <!-- /.addvideo-text__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="addvideo-text__title">Новое видео</h2>
                    <!-- /.addvideo-text__title -->
                </div>
                <!-- /.addvideo-text -->
                <div class="addvideo-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
            </div>
            <!-- /.addvideo-header -->

            <div class="addvideo-block">
                <form action="" class="addvideo-form">
                    <label for="">Название видео</label>
                    <input type="text">
                    <label for="">Тема видео</label>
                    <input type="text">
                    <label for="">Ссылка на YouTube</label>
                    <input type="text"> <br>
                    <button class="button addvideo__button">Добавить видео</button>
                </form>
                <!-- /.addvideo-form -->
            </div>
            <!-- /.addvideo-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>