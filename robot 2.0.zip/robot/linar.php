<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Партнеры / Линейная структура</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="linar-header">
                <div class="linar-text">
                    <h2 class="linar-text__pretitle">Партнеры</h2>
                    <!-- /.linar-text__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="linar-text__title">Линейная структура</h2>
                    <!-- /.linar-text__title -->
                </div>
                <!-- /.linar-text -->
                <div class="linar-price">
                    <img src="img/wallet.png" alt="wallet">
                    <span class="price">0.00 QB</span>
                </div>
            </div>
            <!-- /.linar-header -->

            <div class="linar-block"></div>
            <!-- /.linar-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>