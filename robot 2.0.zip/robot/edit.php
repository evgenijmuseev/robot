<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>FAQ / Добавление (редактирование) вопросов</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="edit-header">
                <div class="edit-header__text">
                    <h3 class="edit-header__subtitle">FAQ</h3>
                    <!-- /.edit-header__subtitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="edit-header__title">Новый вопрос</h2>
                </div>
                <!-- /.edit-header__title -->
                <div class="edit-header__price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
            </div>
            <!-- /.edit-header -->
            <div class="edit-block">
                <form action="" class="edit-form">
                    <label for="question">Вопрос</label>
                    <input type="text" require id="question" class="question">
                    <label for="answer">Ответ</label>
                    <textarea name="" id="answer"></textarea>
                    <button class="button edit__button">Добавить вопрос</button> <!-- /.button edit__button -->
                </form>
                <!-- /.edit-form -->
            </div>
            <!-- /.edit-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>