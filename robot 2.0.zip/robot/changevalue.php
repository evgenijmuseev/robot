<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Обмен валют</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="changevalue-header">
                <h2 class="changevalue-header__title">Обмен валют</h2>
                <!-- /.changevalue-header__title -->
                <div class="changevalue-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price --></div>
                <!-- /.changevalue-price -->
            </div>
            <!-- /.changevalue-header -->
            <div class="changevalue-block">
                <div class="changevalue-ad">
                    <a href="adcurrent.php">Разместить объявление</a>
                    <div class="label-block">
                        <span class="label-block__title">Показать:</span>
                        <!-- /.label-block__title -->
                        <label for="all">
                            <span>Все</span>
                            <input type="radio" id="all">
                        </label>
                        <label for="active">
                            <span>Активные</span>
                            <input type="radio" id="active">
                        </label>
                    </div>
                    <!-- /.label-block -->
                </div>
                <!-- /.changevalue-ad -->
                <div class="table-wrapper">
                    <table class="table">
                            <thead>
                                <tr>
                                    <td>Дата объявления</td>
                                    <td>Автор</td>
                                    <td>Тема объявления</td>
                                    <td>Количество ответов</td>
                                    <td>Статус</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="row">
                                    <td>2020-06-08 <br>
                                    09:08:47</td>
                                    <td>arizold</td>
                                    <td>Определенная тема</td>
                                    <td>26</td>
                                    <td>Не активно</td>
                                </tr>
                                <tr class="row">
                                    <td>2020-06-08 <br>
                                    09:08:47</td>
                                    <td>arizold</td>
                                    <td>Определенная тема</td>
                                    <td>26</td>
                                    <td>Не активно</td>
                                </tr>
                                <tr class="row">
                                    <td>2020-06-08 <br>
                                    09:08:47</td>
                                    <td>arizold</td>
                                    <td>Определенная тема</td>
                                    <td>26</td>
                                    <td>Не активно</td>
                                </tr>
                                <tr class="row">
                                    <td>2020-06-08 <br>
                                    09:08:47</td>
                                    <td>arizold</td>
                                    <td>Определенная тема</td>
                                    <td>26</td>
                                    <td>Не активно</td>
                                </tr>
                                <tr class="row">
                                    <td>2020-06-08 <br>
                                    09:08:47</td>
                                    <td>arizold</td>
                                    <td>Определенная тема</td>
                                    <td>26</td>
                                    <td>Не активно</td>
                                </tr>
                            </tbody>
                        </table>
                </div>
            </div>
            <!-- /.changevalue-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>