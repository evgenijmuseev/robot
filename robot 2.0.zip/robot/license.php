<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Лицензии</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="license-header">
                <h2 class="license-header__title">Лицензии</h2>
                <!-- /.license-header__title -->
                <div class="license-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price --></div>
                <!-- /.license-price -->
            </div>
            <!-- /.license-header -->
            <div class="license-block">
                <div class="license-item">
                    <h2 class="license-item__title">Робот <span class="robot-go">Go</span></h2>
                    <span class="license-item__price price-go">$ 250</span>
                    <img src="img/license/logo-qb.png" alt="logo">
                </div>
                <!-- /.license-item -->
                <div class="license-item">
                    <h2 class="license-item__title">Робот <span class="robot-pro">Pro</spa></h2>
                    <span class="license-item__price price-pro">$ 500</span>
                    <img src="img/license/logo-qb.png" alt="logo">
                </div>
                <!-- /.license-item -->
            </div>
            <!-- /.license-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>