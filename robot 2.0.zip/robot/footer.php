<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
<script>
    $('.menu-btn').on("click", function(e) {
        e.preventDefault();
        $(".menu").toggleClass("menu-active");
    });

    $('.menu-link-wallet').on("click", function() {
        $(".wallet-menu-nav").css("display", "block");
    });

    $('.menu-link-partner').on("click", function(e) {
        $(".partner-menu-nav").css("display", "block");
    });

    $('.menu-link-total').on("click", function(e) {
        $(".total-menu-nav").css("display", "block");
    });

    $('.menu-link-study').on("click", function(e) {
        $(".study-menu-nav").css("display", "block");
    });

    $('.menu-link-faq').on("click", function(e) {
        $(".faq-menu-nav").css("display", "block");
    });

    $('.menu-link-profile').on("click", function(e) {
        $(".profile-menu-nav").css("display", "block");
    });

    $('.menu-link-admin').on("click", function(e) {
        $(".admin-menu-nav").css("display", "block");
    });


</script>
<script src="js/script.js"></script>
</body>
</html>