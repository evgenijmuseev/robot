<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Настройка профиля / Платежные реквизиты</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <section class="props">

                <div class="props-header">
                    <div class="props-text">
                        <h2 class="props-text__pretitle">Настройка профиля</h2>
                        <!-- /.props-text__pretitle -->
                        <img src="img/arrow-right.png" alt="arrow">
                        <h2 class="props-text__title">Платежные реквизиты</h2>
                        <!-- /.props-text__title -->
                    </div>
                    <!-- /.props-text -->
                    <div class="props-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
                </div>
                <!-- /.props-header -->

                <div class="props-block">
                    <form action="" class="props-form">
                        <h2 class="props-form__title">Платежная система 1</h2>
                        <!-- /.props-form__title -->
                        <label for="">Номер счета</label><br>
                        <input type="text">
                        <h2 class="props-form__title">Платежная система 2</h2>
                        <!-- /.props-form__title -->
                        <label for="">Номер счета</label><br>
                        <input type="text"><br>
                        <button class="button props__button">Сохранить</button>
                        <!-- /.button props__button -->
                    </form>
                    <!-- /.props-form -->
                </div>
                <!-- /.props-block -->

            </section>
            <!-- /.props -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>