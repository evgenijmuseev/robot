<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Настройка профиля / Общая информация</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="profile-header">
                <div class="profile-text">
                    <h2 class="profile-text__pretitle">Настройка профиля</h2>
                    <!-- /.profile-text__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="profile-text__title">Общая информация</h2>
                    <!-- /.profile-text__title -->
                </div>
                <!-- /.profile-text -->
                <div class="profile-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
                <!-- /.profile-price -->
            </div>
            <!-- /.profile-header -->
            <div class="profile-block">
                <form action="" class="profile-form">
                    <div class="profile-data">
                        <h2 class="profile-data__title">Основные данные</h2>
                        <label for="">Логин</label>
                        <input type="text" class="profile-login">
                        <label for="">E-mail</label>
                        <input type="text" class="profile-email">
                        <label for="">Телефон</label>
                        <input type="text" class="profile-phone">
                        <div class="profile-date">
                            <label for="">Дата рождения</label>
                            <input type="text" placeholder="День">
                            <input type="text" placeholder="Месяц">
                            <input type="text" placeholder="Год">
                        </div>
                        <!-- /.profile-date -->
                    </div>
                    <!-- /.profile-data -->
                    <div class="profile-network">
                        <h2 class="profile-network__title">Социальные сети</h2>
                        <!-- /.profile-network__title -->
                        <label for="">Ссылка на Вокнтакты</label>
                        <input type="text">
                        <label for="">Ссылка на Facebook</label>
                        <input type="text">
                        <label for="">Ссылка на Instagram</label>
                        <input type="text">
                        <label for="">Ссылка на Twitter</label>
                        <input type="text">
                    </div>
                    <!-- /.profile-network -->
                </form>
                <!-- /.profile-form -->
                <button class="button profile__button">Сохранить изменения</button>
            </div>
            <!-- /.profile-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>