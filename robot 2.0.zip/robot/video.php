<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Обучающие материалы / Видео</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="video-header">
                <div class="video-text">
                    <h2 class="video-text__pretitle">Обучающие материалы</h2>
                    <!-- /.video-text__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="video-text__title">Установка Q Robot</h2>
                    <!-- /.video-text__title -->
                </div>
                <!-- /.video-text -->
                <div class="video-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
                <!-- /.video-price -->
            </div>
            <!-- /.video-header -->
            <div class="video-block">
                <iframe   iframe width="560" height="315" src="https://www.youtube.com/embed/zisSth8fYVU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <div class="video-descr">
                    <h2 class="video-descr__title">Тема: <span>Программы и компоненты</span></h2>
                    <a href="addvideo.php">Редактировать видео</a>
                </div>
            </div>
            <!-- /.video-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>