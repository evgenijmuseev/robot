<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Обучающие материалы</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="training-header">
                <h2 class="training-header__title">Обучающие материалы</h2>
                <!-- /.training-header__title -->
                <div class="training-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
            </div>
            <!-- /.training-header -->
            <div class="training-block">
                <div class="training-item">
                    <img src="img/training/training-img.jpg" alt="training-img">
                    <h2 class="training-item__title">Установка Q Robot</h2>
                    <!-- /.training-item__title -->
                </div>
                <!-- /.training-item -->
                <div class="training-item">
                    <img src="img/training/training-img.jpg" alt="training-img">
                    <h2 class="training-item__title">Установка Q Robot</h2>
                    <!-- /.training-item__title -->
                </div>
                <!-- /.training-item -->
                <div class="training-item">
                    <img src="img/training/training-img.jpg" alt="training-img">
                    <h2 class="training-item__title">Установка Q Robot</h2>
                    <!-- /.training-item__title -->
                </div>
                <!-- /.training-item -->
                <div class="training-item">
                    <img src="img/training/training-img.jpg" alt="training-img">
                    <h2 class="training-item__title">Установка Q Robot</h2>
                    <!-- /.training-item__title -->
                </div>
                <!-- /.training-item -->
                <div class="training-item">
                    <img src="img/training/training-img.jpg" alt="training-img">
                    <h2 class="training-item__title">Установка Q Robot</h2>
                    <!-- /.training-item__title -->
                </div>
                <!-- /.training-item -->
                <div class="training-item">
                    <img src="img/training/training-img.jpg" alt="training-img">
                    <h2 class="training-item__title">Установка Q Robot</h2>
                    <!-- /.training-item__title -->
                </div>
                <!-- /.training-item -->
            </div>
            <!-- /.training-block -->
            <button class="button training__button">Добавить видео</button>
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>