<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="shortcut icon" href="img/favicon.svg" type="image/x-icon">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Кошелек / История операций</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="walletoperation-header">
                <div class="walletoperation-text">
                    <h2 class="walletoperation-text__pretitle">Кошелек</h2>
                    <!-- /.walletoperation__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="walletoperation-text__title">История операций</h2>
                    <!-- /.walletoperation__title -->
                </div>
                <!-- /.walletoperation-text -->
                <div class="walletoperation-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price --></div>
                <!-- /.walletoperation-price -->
            </div>
            <!-- /.walletoperation-header -->
            <div class="walletoperation-block">
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <td>Дата</td>
                                <td>Сумма</td>
                                <td>Операция</td>
                                <td>Баланс после операции</td>
                                <td>Комментарий</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td class="prompt-td">
                                    <img src="img/walletoperation/i-stroke.png" alt="Комментарий" class="comment">
                                    <div class="table-prompt">
                                        <p>Начислено 3% по инвестиционному маркетингу от участника SemVal</p>
                                    </div>
                                    <!-- /.table-prompt -->
                                </td>
                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td class="prompt-td">
                                    <img src="img/walletoperation/i-stroke.png" alt="Комментарий" class="comment">
                                    <div class="table-prompt">
                                        <p>Начислено 3% по инвестиционному маркетингу от участника SemVal</p>
                                    </div>
                                    <!-- /.table-prompt -->
                                </td>                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td class="prompt-td">
                                    <img src="img/walletoperation/i-stroke.png" alt="Комментарий" class="comment">
                                    <div class="table-prompt">
                                        <p>Начислено 3% по инвестиционному маркетингу от участника SemVal</p>
                                    </div>
                                    <!-- /.table-prompt -->
                                </td>                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td class="prompt-td">
                                    <img src="img/walletoperation/i-stroke.png" alt="Комментарий" class="comment">
                                    <div class="table-prompt">
                                        <p>Начислено 3% по инвестиционному маркетингу от участника SemVal</p>
                                    </div>
                                    <!-- /.table-prompt -->
                                </td>                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td class="prompt-td">
                                    <img src="img/walletoperation/i-stroke.png" alt="Комментарий" class="comment">
                                    <div class="table-prompt">
                                        <p>Начислено 3% по инвестиционному маркетингу от участника SemVal</p>
                                    </div>
                                    <!-- /.table-prompt -->
                                </td>                            </tr>
                        </tbody>
                    </table>
                </div>
                <button class="button walletoperation__button">Показать еще</button> <!-- /.button walletoperation__button -->
            </div>
            <!-- /.walletoperation-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>