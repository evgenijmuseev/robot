<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Ошибка</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <section class="error">
                <div class="error-header">
                    <div class="error-header__price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
                </div>
                <div class="error-block">
                    <div class="error-text">
                        <h2 class="error-text__title">Страница не найдена</h2>
                        <!-- /.error-text__title -->
                        <img src="img/error/404.png" alt="404" class="error-img__small">
                        <h3 class="error-text__subtitle">Вы можете перейти на другие:</h3>
                        <!-- /.error-text__subtitle -->
                        <div class="error-menu">
                            <ul class="error-list">
                                <li class="error-list__item"><a href="">Профиль</a></li>
                                <li class="error-list__item"><a href="">Управление финансами</a></li>
                                <li class="error-list__item"><a href="">История операций</a></li>
                                <li class="error-list__item"><a href="">Линейная структура</a></li>
                                <li class="error-list__item"><a href="">Бинарная структура</a></li>
                                <li class="error-list__item"><a href="">Лицензии</a></li>
                            </ul>
                            <ul class="error-list">
                                <li class="error-list__item"><a href="">Обмен валют</a></li>
                                <li class="error-list__item"><a href="">Обучающие материалы</a></li>
                                <li class="error-list__item"><a href="">Настройка профиля</a></li>
                                <li class="error-list__item"><a href="">Админ-панель</a></li>
                                <li class="error-list__item"><a href="">FAQ</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.error-text -->
                    <img src="img/error/404.png" alt="404" class="error-img">
                </div>
                <!-- /.error-block -->
            </section>
            <!-- /.error -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>