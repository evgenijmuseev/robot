<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Обмен валют / Объявление</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="adcurrent-header">
                <div class="adcurrent-text">
                    <h2 class="adcurrent-text__pretitle">Обмен валют</h2>
                    <!-- /.adcurrent-text__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="adcurrent-text__title">Объявление</h2>
                    <!-- /.adcurrent-text__title -->
                </div>
                <!-- /.adcurrent-text -->
                <div class="adcurrent-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
            </div>
            <!-- /.adcurrent-header -->
            
            <div class="adcurrent-block">
                <div class="adcurrent-block__header">
                    <h2>Статистика объявления</h2>
                    <a href="adver.php" class="adcurrent__link">Редактировать объявление</a>
                </div>
                <div class="adcurrent-statistic">
                    <div class="adcurrent-info">
                        <div class="adcurrent-info__status">
                            <label>Статус</label>
                            <span>Активно</span>
                        </div>
                        <!-- /.adcurrent-info__status -->
                        <div class="adcurrent-info__data">
                            <label>Дата</label>
                            <span>2020-06-08 / 09:08:47</span>
                        </div>
                        <!-- /.adcurrent-info__data -->
                        <div class="adcurrent-info__author">
                            <label>Автор</label>
                            <span>arizold</span>
                        </div>
                        <!-- /.adcurrent-info__author -->
                        <div class="adcurrent-info__subject">
                            <label>Тема</label>
                            <span>Определенная тема</span>
                        </div>
                        <!-- /.adcurrent-info__subject -->
                        <div class="adcurrent-info__view">
                            <label>Количество просмотров</label>
                            <span>12</span>
                        </div>
                        <!-- /.adcurrent-info__view -->
                        <div class="adcurrent-info__answer">
                            <label>Количество ответов</label>
                            <span>3</span>
                        </div>
                        <!-- /.adcurrent-info__answer -->
                    </div>
                    <!-- /.adcurrent-info -->
                    <div class="adcurrent-descr">
                        <h1 class="addcurrent-descr__titles">Текст</h1>
                        <!-- /.addcurrent-text__title -->
                        <p class="adcurrent-descr__text">Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким. Определенный текст ответа, который может быть длинным или коротким.</p>
                        <!-- /.adcurrent-text__descr -->
                        <a href="adver.php" class="adcurrent-link__active">Редактировать объявление</a>
                    </div>
                    <!-- /.adcurrent-text -->
                </div>
                <!-- /.adcurrent-statistic -->
                <div class="adcurrent-answer">
                    <h2 class="adcurrent-answer__title">Список ответов</h2>
                    <!-- /.addcurrent-answer__title -->
                    <table>
                        <thead>
                            <tr>
                                <td>Дата</td>
                                <td>Автор ответа</td>
                                <td>Текст ответа</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                    09:08:47</td>
                                <td>arizold</td>
                                <td>Определенный текст ответа, который может быть длинным или коротким</td>
                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                    09:08:47</td>
                                <td>arizold</td>
                                <td>Определенный текст ответа, который может быть длинным или коротким</td>
                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                    09:08:47</td>
                                <td>arizold</td>
                                <td>Определенный текст ответа, который может быть длинным или коротким</td>
                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                    09:08:47</td>
                                <td>arizold</td>
                                <td>Определенный текст ответа, который может быть длинным или коротким</td>
                            </tr>
                            <tr class="row">
                                <td>2020-06-08 <br>
                                    09:08:47</td>
                                <td>arizold</td>
                                <td>Определенный текст ответа, который может быть длинным или коротким</td>
                            </tr>
                        </tbody>
                    </table>
                    <form action="" class="adcurrent-form">
                    <textarea name="" id=""></textarea> <!-- /# -->
                    <button class="button adcurrent__button">Добавить ответ</button> <!-- /.button adcurrent__button --></form>
                    <!-- /.adcurrent-form -->
                </div>
                <!-- /.adcurrent-answer -->
            </div>
            <!-- /.adcurrent-block -->

        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>