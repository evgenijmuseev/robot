<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="shortcut icon" href="img/favicon.svg" type="image/x-icon">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Кошелек / Управление финансами</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="walletcontrol-header">
                <div class="walletcontrol-text">
                    <h2 class="walletcontrol-text__pretitle">Кошелек</h2>
                    <!-- /.walletcontrol-text__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="walletcontrol-text__title">Управление финансами</h2>
                    <!-- /.walletcontrol-text__title -->
                </div>
                <!-- /.walletcontrol-text -->

                <div class="walletcontrol-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price --></div>
                <!-- /.walletcontrol-price -->
            </div>
            <!-- /.walletcontrol-header -->

            <div class="walletcontrol-block">
                <div class="walletcontrol-money">
                    <div class="walletcontrol-money-block">
                        <h1>Текущий баланс</h1>
                        <h2>1 253 041.59 <span>QB</span></h2>
                    </div>
                    <div class="walletcontrol-money-block">
                        <h1>Всего выведено</h1>
                        <h2>1 159 099.23 <span>$</span></h2>
                    </div>
                </div>
                <!-- /.walletcontrol-money -->
                <div class="block-money">
                    <div class="walletcontrol-refill">
                        <h1>Пополнение кошелька</h1>
                        <form action="" class="refill-form">
                            <input type="text" placeholder="Сумма пополнения" class="input-total">
                            <h3 class="refill-form__subtitle">Платежная система</h3>
                            <!-- /.refill-form__subtitle -->
                            <label for="system-1">
                                <input type="radio" id="system-1">
                                <span>Платежная система 1</span>
                            </label>
                            <label for="system-2">
                                <input type="radio" id="system-2">
                                <span>Платежная система 2</span>
                            </label>
                            <label for="system-3">
                                <input type="radio" id="system-3">
                                <span>Платежная система 3</span>
                            </label>
                            <button class="button walletcontrol-refill__button">Пополнить баланс</button> <!-- /.button walletcontrol-refill__button -->
                        </form>
                        <!-- /.refill-form -->
                    </div>
                    <!-- /.walletcontrol-refill -->
                    <div class="walletcontrol-output">
                        <h1>Вывод средств</h1>
                        <form action="" class="output-form-first">
                            <input type="text" placeholder="Сумма вывода">
                            <button class="button output-form-first__button">Вывести средства</button>
                        </form>
                        <h1 class="output-form__title">Перевод другому участнику</h1>
                        <!-- /.refill-form__title -->
                        <!-- /.output-form-first -->
                        <form action="" class="output-form-second">
                            <input type="text" placeholder="Логин участника"> <br>
                            <input type="text" placeholder="Сумма перевода" class="total">
                            <button class="button output-form-second__button">Перевести</button> <!-- /.button output-form-second__button -->
                        </form>
                        <!-- /.output-form-second -->
                    </div>
                    <!-- /.walletcontrol-output -->
                </div>
            </div>
            <!-- /.walletcontrol-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>