<div class="menu">
    <div class="menu-block">
        <div class="menu-header">
            <div class="menu-user">
                <a href=""><img src="img/menu-2/Photo.png" alt="Пользователь"></a>
                <span>arefevIG</span>
            </div>
            <!-- /.menu-user -->
            <div class="menu-text">
                <div class="menu-icons">
                    <a href=""><img src="img/menu-2/bell.png" alt="bell"></a>
                    <a href=""><img src="img/menu-2/settings.png" alt="settings"></a>
                </div>
                <!-- /.icons -->
                <div class="menu-total">
                    <img src="img/menu-2/wallet.png" alt="wallet">
                    <span>0.00 TC</span>
                </div>
                <!-- /.total -->
            </div>
            <!-- /.menu-text -->
        </div>
        <!-- /.menu-header -->
        <div class="menu-body">
            <ul class="menu-list">
                <li><a href="userprofile.php"><img src="img/menu-2/home.png" alt="">Профиль</a></li>
                <li class="wallet-menu menu-link-wallet"><a href="#"><img src="img/menu-2/wallet-2.png" alt="">Кошелек <img src="img/arrow-right.png" alt="arrow"></a>
                    <ul class="wallet-menu-nav">
                        <li><a href="walletcontrol.php">Управление финансами</a></li>
                        <li><a href="walletoperation.php">История операций</a></li>
                    </ul>
                </li>
                <li class="partner-menu menu-link-partner"><a href="#"><img src="img/menu-2/line-structure.png" alt="">Партнеры <img src="img/arrow-right.png" alt="arrow"></a>
                    <ul class="partner-menu-nav">
                        <li><a href="linar.php">Линейная структура</a></li>
                        <li><a href="binary.php">Бинарная стурктура</a></li>
                    </ul>
                </li>
                <li><a href=""><img src="img/menu-2/licence.png" alt="">Лицензии</a></li>
                <li class="total-menu menu-link-total"><a href="#"><img src="img/menu-2/exchange.png" alt="">Обмен валют <img src="img/arrow-right.png" alt="arrow"></a>
                    <ul class="total-menu-nav">
                        <li><a href="changevalue.php">Обмен валют</a></li>
                        <li><a href="adcurrent.php">Объявление</a></li>
                        <li><a href="adver.php">Добавление (редактирование)</a></li>
                    </ul>
                </li>
                <li class="study-menu menu-link-study"><a href="#"><img src="img/menu-2/learn.png" alt="">Обучающие материалы <img src="img/arrow-right.png" alt="arrow"></a>
                    <ul class="study-menu-nav">
                        <li><a href="training.php">Обучающие материалы</a></li>
                        <li><a href="video.php">Видео</a></li>
                        <li><a href="addvideo.php">Добавление и редактирование видео</a></li>
                    </ul>
                </li>
                <li class="faq-menu menu-link-faq"><a href="#"><img src="img/menu-2/faq.png" alt="">FAQ <img src="img/arrow-right.png" alt="arrow"></a>
                    <ul class="faq-menu-nav">
                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="edit.php">Добавление (редактирование) вопросов</a></li>
                    </ul>
                </li>
                <li class="profile-menu menu-link-profile"><a href="#"><img src="img/menu-2/settings-2.png" alt="">Настройка профиля <img src="img/arrow-right.png" alt="arrow"></a>
                    <ul class="profile-menu-nav">
                        <li><a href="password.php">Смена пароля</a></li>
                        <li><a href="props.php">Платежные реквизиты</a></li>
                    </ul>
                </li>
                <li class="admin-menu menu-link-admin"><a href="#"><img src="img/menu-2/admin-panel-solid.png" alt="">Админ панель <img src="img/arrow-right.png" alt="arrow"></a>
                    <ul class="admin-menu-nav">
                        <li><a href="profile.php">Пользователь</a></li>
                        <li><a href="activity.php">Транзакции</a></li>
                    </ul>
                </li>
            </ul>
        </div>
        <!-- /.menu-body -->
        <a href=""><img src="img/menu-2/logo-qb.png" alt="logo" class="logo"></a>
    </div>
    <!-- /.menu-block -->
</div>


<nav class="navbar"></nav>
    <div class="container">
        <div class="navbar-block">
            <a href="userprofile.php" class="navbar-logo"><img src="img/menu/logo.png" alt="logo"></a>
            <!-- /.navbar-logo -->
            <ul class="navbar-menu">
                <li class="navbar-menu__link"><a href="userprofile.php">Профиль</a></li>
                <li class="navbar-menu__link wallet"><a href="">Кошелек</a>
                    <ul class="wallet-nav">
                        <li><a href="walletcontrol.php">Управление финансами</a></li>
                        <li><a href="walletoperation.php">История операций</a></li>
                    </ul>
                </li>
                <li class="navbar-menu__link partner"><a href="">Партнеры</a>
                    <ul class="partner-nav">
                        <li><a href="linar.php">Линейная структура</a></li>
                        <li><a href="binary.php">Бинарная стурктура</a></li>
                    </ul>
                </li>
                <li class="navbar-menu__link"><a href="license.php">Лицензии</a></li>
                <li class="navbar-menu__link total"><a href="">Обмен валют</a>
                    <ul class="total-nav">
                        <li><a href="changevalue.php">Обмен валют</a></li>
                        <li><a href="adcurrent.php">Объявление</a></li>
                        <li><a href="adver.php">Добавление (редактирование)</a></li>
                    </ul>
                </li>
                <li class="navbar-menu__link study"><a href="">Обучение</a>
                    <ul class="study-nav">
                        <li><a href="training.php">Обучающие материалы</a></li>
                        <li><a href="video.php">Видео</a></li>
                        <li><a href="addvideo.php">Добавление и редактирование видео</a></li>
                    </ul>
                </li>
                <li class="navbar-menu__link faq-menu"><a href="">FAQ</a>
                    <ul class="faq-menu-nav">
                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="edit.php">Добавление (редактирование) вопросов</a></li>
                    </ul>
                </li>
            </ul>
            <!-- /.navbar-menu -->
            <div class="navbar-profile">
                <div class="profile-block">
                    <a href="" class="menu-btn"><span></span></a> <!-- /.menu-btn -->
                    <a href=""><img src="img/menu/bell-icon.svg" alt="bell" class="menu-icon"></a>
                    <a href=""><img src="img/menu/user-icon.svg" alt="user" class="menu-icon"></a>
                    <a href="profile.php"><img src="img/menu/settings-icon.svg" alt="settings" class="menu-icon"></a>
                    <a href=""><img src="img/menu/man.png" alt="man" class="man"></a>
                </div>
                <!-- /.profile-block -->
            </div>
            <!-- /.navbar-profile -->
        </div>
        <!-- /.navbar-block -->
    </div>
    <!-- /.container -->
</nav>
<!-- /.navbar -->