<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Админ-панель / Редактирование (добавление) пользователя</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <section class="adduser">

                <div class="adduser-header">
                    <div class="adduser-text">
                        <h2 class="adduser-text__pretitle">Админ-панель</h2>
                        <!-- /.adduser-text__pretitle -->
                        <img src="img/arrow-right.png" alt="arrow">
                        <h2 class="adduser-text__title">Новый пользователь</h2>
                        <!-- /.adduser-text__title -->
                    </div>
                    <!-- /.adduser-text -->
                    <div class="adduser-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
                </div>
                <!-- /.adduser-header -->

                <div class="adduser-block">
                    <div class="adduser-data">
                        <h2 class="adduser-data__title">Основные данные</h2>
                        <!-- /.adduser-data__title -->
                        <form action="" class="data-form">
                            <label for="" class="adduser-login">Логин</label>
                            <input type="text">
                            <label for="" class="adduser-email">E-mail</label>
                            <input type="text">
                            <div class="right-refer">
                                <label for="">Прямой реферер</label>
                                <div class="select">
                                    <div class="select">
                                <div class="select-header">
                                    <div class="select-header__current">arizold</div>
                                    <!-- /.select-header__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow">
                                </div>
                                <!-- /.select-header -->
                                <div class="select-body">
                                    <div class="select-item">Пункт 1</div>
                                    <div class="select-item">Пункт 2</div>
                                    <div class="select-item">Пункт 3</div>
                                </div>
                            </div>
                            <!-- /.select -->
                                </div>
                            </div>
                                <div class="direction-refer">
                                    <label for="">Направление реферера</label>
                                    <div class="select">
                                        <div class="select">
                                    <div class="select-header">
                                        <div class="select-header__current">левое</div>
                                        <!-- /.select-header__current -->
                                        <img src="img/arrow-down-solid.svg" alt="arrow">
                                    </div>
                                    <!-- /.select-header -->
                                    <div class="select-body">
                                        <div class="select-item">Пункт 1</div>
                                        <div class="select-item">Пункт 2</div>
                                        <div class="select-item">Пункт 3</div>
                                    </div>
                                </div>
                                <!-- /.select -->
                                </div>
                            </div>
                        </form>
                        <!-- /.data-form -->
                    </div>
                    <!-- /.adduser-data -->
                    <div class="adduser-position">
                        <h2 class="adduser-position__title">Положение в бинарном дереве</h2>
                        <!-- /.adduser-position__title -->
                    </div>
                    <!-- /.adduser-position -->
                </div>
                <!-- /.adduser-block -->
            </section>
            <!-- /.adduser -->
        </main>
    </div>
<?php include 'footer.php'; ?>