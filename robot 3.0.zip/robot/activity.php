<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Редактирование (добавление) транзакции</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="activity-header">
                <div class="activity-text">
                    <h2 class="activity-header__pretitle">Админ-панель</h2>
                    <!-- /.activity-header__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="activity-header__title">Новая транзакция</h2>
                    <!-- /.activity-header__title -->
                </div>
                <div class="activity-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
            </div>
            <!-- /.activity-header -->
            <div class="activity-block">
                <form action="" class="activity-form">
                    <div class="activity-info">
                        <div class="activity-user">
                            <label for="">Пользователь</label>
                            <input type="text">
                        </div>
                        <!-- /.activity-user -->
                        <div class="activity-date">
                            <label for="">Дата</label>
                            <div class="activity-date__wrapper">
                                <input type="text" placeholder="День">
                                <input type="text" placeholder="Месяц">
                                <input type="text" placeholder="Год">
                            </div>
                        </div>
                        <div class="activity-total">
                            <label for="">Сумма</label>
                            <input type="text">
                        </div>
                        <div class="activity-operation">
                            <label for="">Операция</label>
                            <div class="select">
                                <div class="select-header">
                                    <div class="select-header__current">Исходящий перевод</div>
                                    <!-- /.select-header__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow">
                                </div>
                                <!-- /.select-header -->
                                <div class="select-body">
                                    <div class="select-item">Пункт 1</div>
                                    <div class="select-item">Пункт 2</div>
                                    <div class="select-item">Пункт 3</div>
                                </div>
                            </div>
                            <!-- /.select -->
                        </div>
                        <div class="activity-balance">
                            <label for="">Баланс после операции</label>
                            <input type="text">
                        </div>
                    </div>
                    <!-- /.activity-info -->
                    <div class="activity-comment">
                        <textarea name="" id="" placeholder="Комментарий"></textarea>
                    </div>
                    <!-- /.activity-comment -->
                </form>
                <button class="button activity__button">Сохранить</button> <!-- /.button activity__button -->
                <!-- /.activity -->
            </div>
            <!-- /.activity-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>