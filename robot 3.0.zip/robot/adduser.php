<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Админ-панель / Редактирование (добавление) пользователя</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <section class="adduser">

                <div class="adduser-header">
                    <div class="adduser-text">
                        <h2 class="adduser-text__pretitle">Админ-панель</h2>
                        <!-- /.adduser-text__pretitle -->
                        <img src="img/arrow-right.png" alt="arrow">
                        <h2 class="adduser-text__title">Новый пользователь</h2>
                        <!-- /.adduser-text__title -->
                    </div>
                    <!-- /.adduser-text -->
                    <div class="adduser-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
                </div>
                <!-- /.adduser-header -->

                <div class="adduser-block">
                    <div class="adduser-data">
                        <h2 class="adduser-data__title">Основные данные</h2>
                        <!-- /.adduser-data__title -->
                        <form action="" class="data-form">
                            <label for="" class="adduser-login">Логин</label>
                            <input type="text">
                            <label for="" class="adduser-email">E-mail</label>
                            <input type="text">

                            <div class="select-block">
                                <div class="select-block__title">Прямой реферер</div>
                                <!-- /.select-block__title -->
                                <div class="select">
                                    <div class="select__header">
                                        <div class="select__current">arefevIG</div>
                                        <!-- /.select__current -->
                                        <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                    </div>
                                    <!-- /.select__header -->
                                    <div class="select__body">
                                        <div class="select-item">arefevIG</div>
                                        <!-- /.select-item -->
                                        <div class="select-item">trader</div>
                                        <!-- /.select-item -->
                                        <div class="select-item">investman</div>
                                        <!-- /.select-item -->
                                    </div>
                                    <!-- /.select__body -->
                                </div>
                                <!-- /.select -->
                            </div>
                            <!-- /.select-block -->

                        <div class="select-block">
                            <div class="select-block__title">Направление реферера</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">Левое</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">Левое</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Правое</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Левое</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                        <button class="button adduser__button">Сохранить</button> <!-- /.button adduser__button -->
                        </form>
                        <!-- /.data-form -->
                    </div>
                    <!-- /.adduser-data -->
                    <div class="adduser-position">
                        <h2 class="adduser-position__title">Положение в бинарном дереве</h2>
                        <!-- /.adduser-position__title -->

                        <div class="select-block">
                            <div class="select-block__title">Вышестоящий</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">arefevIG</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">arefevIG</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">trader</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">investman</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                        <div class="select-block">
                            <div class="select-block__title">Нижестоящий слева</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">trader</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">trader</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">arefevIG</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">investman</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                        <div class="select-block">
                            <div class="select-block__title">Нижестоящий справа</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">investman</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">investman</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">trader</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">investman</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                    </div>
                    <!-- /.adduser-position -->
                </div>
                <!-- /.adduser-block -->
            </section>
            <!-- /.adduser -->
        </main>
    </div>
<?php include 'footer.php'; ?>