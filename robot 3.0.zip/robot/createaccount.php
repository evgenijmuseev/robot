<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="shortcut icon" href="img/favicon.svg" type="image/x-icon">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Регистрация и авторизация</title>
</head>
<body>
    <div class="popup"></div>
        <div class="popup-body">
            <h1 class="popup__title">Создайте аккаунт</h1>
            <!-- /.popup__title -->
            <form action="" class="popup__form">
                <input type="text" placeholder="Имя" class="popup-name">
                <input type="text" placeholder="Email" class="popup-email">
                <input type="text" placeholder="Пароль" class="popup-password">
                <button class="button popup__button">Создать</button>
                <!-- /.button popup__button -->
            </form>
            <!-- /.popup__form -->
            <h3 class="popup__subtitle">Уже есть аккаунт?</h3>
            <!-- /.popup__subtitle -->
            <a href="enteraccount.php" class="popup__link">Войти в личный аккаунт</a> <!-- /.popup__link -->
        </div>
        <!-- /.popup-body -->
    </div>
    <!-- /.popup -->
<?php include 'footer.php'; ?>