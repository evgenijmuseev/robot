<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="shortcut icon" href="img/favicon.svg" type="image/x-icon">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Регистрация и авторизация</title>
</head>
<body>
    <div class="popup">
        <div class="popup-body">
            <h1 class="popup__title">Восстановить пароль</h1>
            <!-- /.popup__title -->
            <form action="" class="popup__form">
                <input type="text" class="popup-email" placeholder="Email">
                <button class="button restore__button">Восстановить</button> <!-- /.button restore__button -->
                <h3 class="popup__subtitle">Уже есть аккаунт?</h3>
            <!-- /.popup__subtitle -->
            <a href="enteraccount.php" class="popup__link">Войти в личный аккаунт</a> <!-- /.popup__link -->
            </form>
            <!-- /.popup__form -->
        </div>
        <!-- /.popup-body -->
    </div>
    <!-- /.popup -->
<?php include 'footer.php'; ?>