<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Обмен валют / Добавление (редактирование)</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="adver-header">
                <div class="adver-text">
                    <h2 class="adver-text__pretitle">Обмен валют</h2>
                    <!-- /.adver-text__pretitle -->
                    <img src="img/arrow-right.png" alt="arrow">
                    <h2 class="adver-text__title">Новое объявление</h2>
                    <!-- /.adver-text__title -->
                </div>
                <!-- /.adver-text -->
                <div class="adver-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
            </div>
            <!-- /.adver-header -->
            <div class="adver-block">
                <form action="" class="adver-form">
                    <label for="">Тема объявления</label>
                    <input type="text">
                    <label for="">Текст объявления</label>
                    <textarea name="" id=""></textarea>
                    <button class="button adver__button">Добавить объявление</button> <!-- /.button adver__button -->
                </form>
                <!-- /.adver-form -->
            </div>
            <!-- /.adver-block -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>