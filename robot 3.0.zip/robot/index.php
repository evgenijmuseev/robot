<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<link rel="stylesheet" href="css/main.css">
<title>Профиль</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="userprofile-header">
                <h2 class="userprofile-header__title">Профиль</h2>
                <!-- /.userprofile-header__title -->
                <div class="userprofile-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price --></div>
                <!-- /.userprofile-price -->
            </div>
            <!-- /.userprofile-header -->

            <div class="userprofile-body">
                <div class="userprofile-data">
                    <div class="userprofile-balance">
                        <h3 class="userprofile-balance__title">Текущий баланс:</h3>
                        <!-- /.userprofile-balance__title -->
                        <div class="data-block">
                            <img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price -->
                        </div>
                        <!-- /.balance-block -->
                    </div>
                    <!-- /.userprofile-balance -->
                    <div class="userprofile-license">
                        <h3 class="userprofile-license__title">Активные лицензии:</h3>
                        <!-- /.userprofile-license__title -->
                        <div class="data-block"><img src="img/userprofile/quantity-licence.png" alt="license"><span>2</span></div>
                        <!-- /.data-block -->
                    </div>
                    <!-- /.userprofile-license -->
                    <div class="userprofile-server">
                        <h3 class="userprofile-server__title">Арендованные серверы:</h3>
                        <!-- /.userprofile-server__title -->
                        <div class="data-block"><img src="img/userprofile/database-storage.png" alt="storage"><span>1</span></div>
                        <!-- /.data-block -->
                    </div>
                    <!-- /.userprofile-server -->
                    <div class="userprofile-refer">
                        <h3 class="userprofile-refer__title">Партнеры:</h3>
                        <!-- /.userprofile-partner__title -->
                        <div class="data-block"><img src="img/userprofile/referral.png" alt="Партнеры"><span>25</span></div>
                        <!-- /.data-block -->
                    </div>
                    <!-- /.userprofile-partner -->
                    <div class="userprofile-side">
                        <h3 class="userprofile-side__title">Сторона регистрации партнера</h3>
                        <!-- /.userprofile-side__title -->
                        <div class="radio-block">
                            <label for="">
                                <span>Левая</span>
                                <input type="radio" class="radio-first">
                            </label>
                            <label for="">
                                <input type="radio" class="radio-second">
                                <span>Правая</span>
                            </label>
                        </div>
                        <!-- /.radio-block -->
                    </div>
                    <!-- /.userprofile-side -->
                </div>
                <!-- /.userprofile-data -->
                
                <div class="userprofile-block">
                    <div class="userprofile-stat">
                        <h2 class="userprofile-stat__title">Статистика</h2>
                        <!-- /.userprofile-stat__title -->
                        <div class="userprofile-bonus">
                            <h3 class="userprofile-bonus__title">Бонусы по линейному маркетингу</h3>
                            <!-- /.userprofile-bonus__title -->
                            <span class="userprofile-bonus__total">$ 1250.00</span>
                            <!-- /.userprofile-bonus__total -->
                        </div>
                        <!-- /.userprofile-bonus -->
                        <div class="userprofile-bonus">
                            <h3 class="userprofile-bonus__title">Бонусы по бинарному маркетингу</h3>
                            <!-- /.userprofile-bonus__title -->
                            <span class="userprofile-bonus__total">$ 359.00</span>
                            <!-- /.userprofile-bonus__total -->
                        </div>
                        <!-- /.userprofile-bonus -->
                        <div class="userprofile-bonus">
                            <h3 class="userprofile-bonus__title">Сумма оборота по левому бинарному направлению</h3>
                            <!-- /.userprofile-bonus__title -->
                            <span class="userprofile-bonus__total">$ 559.00</span>
                            <!-- /.userprofile-bonus__total -->
                        </div>
                        <!-- /.userprofile-bonus -->
                        <div class="userprofile-bonus">
                            <h3 class="userprofile-bonus__title">Сумма оборота по правому бинарному направлению</h3>
                            <!-- /.userprofile-bonus__title -->
                            <span class="userprofile-bonus__total">$ 15159.00</span>
                            <!-- /.userprofile-bonus__total -->
                        </div>
                        <!-- /.userprofile-bonus -->

                        <div class="userprofile-relation">
                            <h2 class="userprofile-relation__title">Соотношение сумм бонусов</h2>
                            <!-- /.userprofile-relation__title -->
                            <img src="img/userprofile/relation.png" alt="Соотношение сумм бонусов" class="relation-lg">
                            <img src="img/userprofile/relation-sm.png" alt="Соотношение сумм бонусов" class="relation-sm">
                        </div>
                        <!-- /.userprofile-relation -->
                    </div>
                    <!-- /.userprofile-stat -->
                    <div class="userprofile-partner">
                        <div class="userprofile-list">
                            <h2 class="userprofile-partner__title">Список партнеров</h2>
                            <!-- /.userprofile-partner__title -->
                            <div class="userprofile-item">
                                <div class="userprofile-info">
                                    <img src="img/panel/user-img.png" alt="Пользователь">
                                    <div class="userprofile-text">
                                        <h3 class="userprofile-info__title">Куратор: arizold</h3>
                                        <!-- /.userprofile-info__title -->
                                        <span class="userprofile-info__email">arizold@yandex.ru</span>
                                        <!-- /.userprofile-info__email -->
                                    </div>
                                </div>
                                <!-- /.userprofile-info -->
                                <img src="img/panel/chat.png" alt="Чат" class="userprofile-img">
                            </div>
                            <!-- /.userprofile-item -->
                            <div class="userprofile-item">
                                <div class="userprofile-info">
                                    <img src="img/panel/user-img.png" alt="Пользователь">
                                    <div class="userprofile-text">
                                        <h3 class="userprofile-info__title">Куратор: arizold</h3>
                                        <!-- /.userprofile-info__title -->
                                        <span class="userprofile-info__email">arizold@yandex.ru</span>
                                        <!-- /.userprofile-info__email -->
                                    </div>
                                </div>
                                <!-- /.userprofile-info -->
                                <img src="img/panel/chat.png" alt="Чат" class="userprofile-img">
                            </div>
                            <!-- /.userprofile-item -->
                            <div class="userprofile-item">
                                <div class="userprofile-info">
                                    <img src="img/panel/user-img.png" alt="Пользователь">
                                    <div class="userprofile-text">
                                        <h3 class="userprofile-info__title">Куратор: arizold</h3>
                                        <!-- /.userprofile-info__title -->
                                        <span class="userprofile-info__email">arizold@yandex.ru</span>
                                        <!-- /.userprofile-info__email -->
                                    </div>
                                </div>
                                <!-- /.userprofile-info -->
                                <img src="img/panel/chat.png" alt="Чат" class="userprofile-img">
                            </div>
                            <!-- /.userprofile-item -->
                            <div class="userprofile-item">
                                <div class="userprofile-info">
                                    <img src="img/panel/user-img.png" alt="Пользователь">
                                    <div class="userprofile-text">
                                        <h3 class="userprofile-info__title">Куратор: arizold</h3>
                                        <!-- /.userprofile-info__title -->
                                        <span class="userprofile-info__email">arizold@yandex.ru</span>
                                        <!-- /.userprofile-info__email -->
                                    </div>
                                </div>
                                <!-- /.userprofile-info -->
                                <img src="img/panel/chat.png" alt="Чат" class="userprofile-img">
                            </div>
                            <!-- /.userprofile-item -->
                            <div class="userprofile-item">
                                <div class="userprofile-info">
                                    <img src="img/panel/user-img.png" alt="Пользователь">
                                    <div class="userprofile-text">
                                        <h3 class="userprofile-info__title">Куратор: arizold</h3>
                                        <!-- /.userprofile-info__title -->
                                        <span class="userprofile-info__email">arizold@yandex.ru</span>
                                        <!-- /.userprofile-info__email -->
                                    </div>
                                </div>
                                <!-- /.userprofile-info -->
                                <img src="img/panel/chat.png" alt="Чат" class="userprofile-img">
                            </div>
                            <!-- /.userprofile-item -->
                            <div class="userprofile-item">
                                <div class="userprofile-info">
                                    <img src="img/panel/user-img.png" alt="Пользователь">
                                    <div class="userprofile-text">
                                        <h3 class="userprofile-info__title">Куратор: arizold</h3>
                                        <!-- /.userprofile-info__title -->
                                        <span class="userprofile-info__email">arizold@yandex.ru</span>
                                        <!-- /.userprofile-info__email -->
                                    </div>
                                </div>
                                <!-- /.userprofile-info -->
                                <img src="img/panel/chat.png" alt="Чат" class="userprofile-img">
                            </div>
                            <!-- /.userprofile-item -->

                        </div>
                        <!-- /.userprofile-list -->
                        <h2 class="userprofile-partner__title">Партнерские ссылки</h2>
                        <!-- /.userprofile-partner__title -->
                        <div class="userprofile-links">
                            <div class="userprofile-link">
                                <div class="userprofile-link-text">
                                    <h3 class="userprofile-link__title">Ссылка на регистрацию:</h3>
                                    <!-- /.userprofile-link__title -->
                                    <span class="link-first">https://site.ru/register?ref=55a7cf9c71fnl883fllsfdjs</span>
                                </div>
                                <!-- /.userprofile-link-text -->
                                <img src="img/userprofile/copy.png" alt="copy" class="copy-first">
                            </div>
                            <!-- /.userprofile-link -->

                            <div class="userprofile-link">
                                <div class="userprofile-link-text">
                                    <h3 class="userprofile-link__title">Ссылка на регистрацию:</h3>
                                    <!-- /.userprofile-link__title -->
                                    <span class="link-second">https://site.ru/register?ref=55a7cf9c71fnl883fllsfdjs</span>
                                </div>
                                <!-- /.userprofile-link-text -->
                                <img src="img/userprofile/copy.png" alt="copy" class="copy-second">
                            </div>
                            <!-- /.userprofile-link -->
                        </div>
                        <!-- /.userprofile-links -->
                    </div>
                    <!-- /.userprofile-partner -->
                </div>
                <!-- /.userprofile-block -->
            </div>
            <!-- /.userprofile-body -->

        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>