document.addEventListener("DOMContentLoaded", function() {
    'use strict';
    // Табы
    let wrapper = document.querySelectorAll(".faq-block"),
        item = document.querySelectorAll('.faq-item'),
        tabContent = document.querySelectorAll(".faq-item__content");

    function hideTabContent() {
        tabContent.forEach((item) => {
            item.style.display = 'none';
            item.classList.remove("content__active");
        });
    }
    hideTabContent();

    function showTabContent(b) {
        for (let i = 0; i < tabContent.length; i++) {
            tabContent[b].style.display = 'block';
            tabContent[b].classList.add("content__active");
        }
    }

    wrapper.forEach((child) => {
        child.addEventListener('click', function(e) {
            let target = e.target; 
            if (target && target.classList.contains("faq-item")) {
                for (let i = 0; i < item.length; i++) {
                    if (item[i] == target) {
                        hideTabContent();
                        showTabContent(i);
                    }
                }
            }
        });
    });

    // Селект
    let select = function() {
        let selectHeader = document.querySelectorAll(".select-header");
        let selectItem = document.querySelectorAll(".select-item");

        selectHeader.forEach((item) => {
            item.addEventListener("click", selectToggle);
        });

        selectItem.forEach((item) => {
            item.addEventListener("click", selectChoose);
        });

        function selectToggle() {
            this.parentElement.classList.toggle('is-active');
        }

        function selectChoose() {
            let text = this.innerText,
                select = this.closest('.select'),
                currentText = select.querySelector(".select-header__current");
                currentText.innerText = text;
                select.classList.remove('is-active');
        }
    }
    select();

    let sel = function() {
        let selectHeader = document.querySelectorAll(".select__header"),
            selectItem = document.querySelectorAll(".select-item");
        
        selectHeader.forEach((item) => {
            item.addEventListener("click", selectToggle);
        });

        function selectToggle() {
            this.parentElement.classList.toggle('is__active');
        }

        selectItem.forEach((item) => {
            item.addEventListener("click", selectChoose);
        });

        function selectChoose() {
            let text = this.innerText,
                select = this.closest('.select'),
                currentText = select.querySelector(".select__current");
                currentText.innerText = text;
                select.classList.remove('is__active');
        }

    }

    sel();
});