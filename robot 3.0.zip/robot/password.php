<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Настройка профиля / Смена пароля</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <section class="password">
                <div class="password-header">
                    <div class="password-text">
                        <h2 class="password-text__pretitle">Настройка профиля</h2>
                        <!-- /.passwrod-text__pretitle -->
                        <img src="img/arrow-right.png" alt="arrow">
                        <h2 class="password-text__title">Смена пароля</h2>
                        <!-- /.password-text__title -->
                    </div>
                    <!-- /.password-text -->
                    <div class="password-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price --></div>
                    <!-- /.password-price -->
                </div>
                <!-- /.password-header -->
                <div class="password-block">
                    <form action="" class="password-form">
                        <label for="">Текущий пароль</label>
                        <input type="text"><br>
                        <label for="">Новый пароль</label>
                        <input type="text"><br>
                        <label for="">Подтверждение нового пароля</label>
                        <input type="text"><br>
                        <button class="button password__button">Сменить пароль</button> <!-- /.button password__button -->
                    </form>
                    <!-- /.password-form -->
                </div>
                <!-- /.password-block -->
            </section>
            <!-- /.password -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>