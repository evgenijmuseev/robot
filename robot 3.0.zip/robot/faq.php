<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>FAQ</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <section class="faq">
                <div class="faq-header">
                    <h2 class="faq-header__title">FAQ</h2>
                    <!-- /.faq-header__title -->
                    <div class="faq-header__price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span></div>
                </div>
                <!-- /.faq-header -->
                <div class="faq-section">
                    <div class="faq-block">
                        <div class="faq-item">
                            <div class="faq-item__header" data-nav="tab-1"><span>Что такое QB Robot?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content" data-nav="tab-1">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header" data-nav="tab-2"><span>Как долго существует робот?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content" data-nav="tab-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Сколько процентов прибыли приносит робот?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Какие риски и гарантии у данного вида инвестиций?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Робот работает в выходные дни?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Нет, так как не работает валютный рынок Forex. Одной из особенностей рынка Forex является то, что он работает круглосуточно с 1:00 понедельника до 00:00 пятницы. Выходные дни на рынке - суббота и воскресенье, так как большинство банков не работает (на рынке крайне низкая ликвидность в эти дни). Как только из рынка выходит один континент, начинает работу другой.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Когда цикл считается закрытым и начисляется бонус?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                    </div>
                    <!-- /.faq-block -->
                    <div class="faq-block">
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Робот работает в выходные дни?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Нет, так как не работает валютный рынок Forex. Одной из особенностей рынка Forex является то, что он работает круглосуточно с 1:00 понедельника до 00:00 пятницы. Выходные дни на рынке - суббота и воскресенье, так как большинство банков не работает (на рынке крайне низкая ликвидность в эти дни). Как только из рынка выходит один континент, начинает работу другой.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Что такое QB Robot?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Сколько процентов прибыли приносит робот?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                        <div class="faq-item">
                            <div class="faq-item__header"><span>Когда цикл считается закрытым и начисляется бонус?</span><img src="img/arrow-down-solid.svg" alt=""></div>
                            <!-- /.faq-item__header -->
                            <p class="faq-item__content">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit iure molestiae perferendis repudiandae soluta officiis vel consequuntur quaerat cumque illum, incidunt autem deleniti commodi quis, animi doloribus itaque veritatis aliquam.</p>
                            <!-- /.faq-item__content -->
                        </div>
                        <!-- /.faq-item -->
                    </div>
                </div>
                <button class="button faq__button">Добавить вопрос</button> <!-- /.button faq__button -->
            </section>
            <!-- /.faq -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>