<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="fonts/stylesheet.css">
<title>Админ-панель</title>
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container">
        <main class="main">
            <div class="panel-header">
                <h2 class="panel-header__title">Админ-панель</h2>
                <!-- /.panel-header__title -->
                <div class="panel-price"><img src="img/wallet.png" alt="wallet"><span class="price">0.00 QB</span> <!-- /.price --></div>
                <!-- /.panel-price -->
            </div>
            <!-- /.panel-header -->
            <div class="panel-body">
                <div class="panel-block">
                    <div class="panel-system">
                        <div class="select-block">
                            <div class="select-block__title">Констант система</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">Вариант 1</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">Вариант 1</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 2</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 3</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                        <div class="select-block">
                            <div class="select-block__title">Констант система</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">Вариант 1</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">Вариант 1</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 2</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 3</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                        <div class="select-block">
                            <div class="select-block__title">Констант система</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">Вариант 1</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">Вариант 1</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 2</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 3</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                        <div class="select-block">
                            <div class="select-block__title">Констант система</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">Вариант 1</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">Вариант 1</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 2</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 3</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->

                        <div class="select-block">
                            <div class="select-block__title">Констант система</div>
                            <!-- /.select-block__title -->
                            <div class="select">
                                <div class="select__header">
                                    <div class="select__current">Вариант 1</div>
                                    <!-- /.select__current -->
                                    <img src="img/arrow-down-solid.svg" alt="arrow" class="select__img">
                                </div>
                                <!-- /.select__header -->
                                <div class="select__body">
                                    <div class="select-item">Вариант 1</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 2</div>
                                    <!-- /.select-item -->
                                    <div class="select-item">Вариант 3</div>
                                    <!-- /.select-item -->
                                </div>
                                <!-- /.select__body -->
                            </div>
                            <!-- /.select -->
                        </div>
                        <!-- /.select-block -->
                    </div>
                    <!-- /.panel-system -->
                    <div class="panel-user">
                        <h2 class="panel-user__title">Список всех пользователей</h2>
                        <!-- /.panel-user__title -->
                        <div class="user-block">
                            <div class="user-info">
                                <img src="img/panel/user-img.png" alt="user-img">
                                <div class="user-text">
                                    <h2 class="user-text__title">arizold</h2>
                                    <!-- /.user-text__title -->
                                    <span>arizold@yandex.ru</span>
                                </div>
                                <!-- /.user-text -->
                            </div>
                            <!-- /.user-info -->
                            <div class="user-img">
                                <a href=""><img src="img/panel/chat.png" alt="chat"></a>
                            </div>
                            <!-- /.user-img -->
                        </div>
                        <!-- /.user-block -->
                        <div class="user-block">
                            <div class="user-info">
                                <img src="img/panel/user-img.png" alt="user-img">
                                <div class="user-text">
                                    <h2 class="user-text__title">arizold</h2>
                                    <!-- /.user-text__title -->
                                    <span>arizold@yandex.ru</span>
                                </div>
                                <!-- /.user-text -->
                            </div>
                            <!-- /.user-info -->
                            <div class="user-img">
                                <a href=""><img src="img/panel/chat.png" alt="chat"></a>
                            </div>
                            <!-- /.user-img -->
                        </div>
                        <!-- /.user-block -->
                        <div class="user-block">
                            <div class="user-info">
                                <img src="img/panel/user-img.png" alt="user-img">
                                <div class="user-text">
                                    <h2 class="user-text__title">arizold</h2>
                                    <!-- /.user-text__title -->
                                    <span>arizold@yandex.ru</span>
                                </div>
                                <!-- /.user-text -->
                            </div>
                            <!-- /.user-info -->
                            <div class="user-img">
                                <a href=""><img src="img/panel/chat.png" alt="chat"></a>
                            </div>
                            <!-- /.user-img -->
                        </div>
                        <!-- /.user-block -->
                        <div class="user-block">
                            <div class="user-info">
                                <img src="img/panel/user-img.png" alt="user-img">
                                <div class="user-text">
                                    <h2 class="user-text__title">arizold</h2>
                                    <!-- /.user-text__title -->
                                    <span>arizold@yandex.ru</span>
                                </div>
                                <!-- /.user-text -->
                            </div>
                            <!-- /.user-info -->
                            <div class="user-img">
                                <a href=""><img src="img/panel/chat.png" alt="chat"></a>
                            </div>
                            <!-- /.user-img -->
                        </div>
                        <!-- /.user-block -->
                        <div class="user-block">
                            <div class="user-info">
                                <img src="img/panel/user-img.png" alt="user-img">
                                <div class="user-text">
                                    <h2 class="user-text__title">arizold</h2>
                                    <!-- /.user-text__title -->
                                    <span>arizold@yandex.ru</span>
                                </div>
                                <!-- /.user-text -->
                            </div>
                            <!-- /.user-info -->
                            <div class="user-img">
                                <a href=""><img src="img/panel/chat.png" alt="chat"></a>
                            </div>
                            <!-- /.user-img -->
                        </div>
                        <!-- /.user-block -->
                        <div class="user-block">
                            <div class="user-info">
                                <img src="img/panel/user-img.png" alt="user-img">
                                <div class="user-text">
                                    <h2 class="user-text__title">arizold</h2>
                                    <!-- /.user-text__title -->
                                    <span>arizold@yandex.ru</span>
                                </div>
                                <!-- /.user-text -->
                            </div>
                            <!-- /.user-info -->
                            <div class="user-img">
                                <a href=""><img src="img/panel/chat.png" alt="chat"></a>
                            </div>
                            <!-- /.user-img -->
                        </div>
                        <!-- /.user-block -->
                        <div class="user-block">
                            <div class="user-info">
                                <img src="img/panel/user-img.png" alt="user-img">
                                <div class="user-text">
                                    <h2 class="user-text__title">arizold</h2>
                                    <!-- /.user-text__title -->
                                    <span>arizold@yandex.ru</span>
                                </div>
                                <!-- /.user-text -->
                            </div>
                            <!-- /.user-info -->
                            <div class="user-img">
                                <a href=""><img src="img/panel/chat.png" alt="chat"></a>
                            </div>
                            <!-- /.user-img -->
                        </div>
                        <!-- /.user-block -->
                    </div>
                    <!-- /.panel-user -->
                </div>
                <!-- /.panel-block -->
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <td>Логин</td>
                                <td>Дата</td>
                                <td>Сумма</td>
                                <td>Операция</td>
                                <td>Баланс после операции</td>
                                <td>Комметарий</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="row">
                                <td>arizold</td>
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td><img src="img/i-stroke.png" alt="i"></td>
                            </tr>
                            <!-- /.row -->
                            <tr class="row">
                                <td>arizold</td>
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td><img src="img/i-stroke.png" alt="i"></td>
                            </tr>
                            <!-- /.row -->
                            <tr class="row">
                                <td>arizold</td>
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td><img src="img/i-stroke.png" alt="i"></td>
                            </tr>
                            <!-- /.row -->
                            <tr class="row">
                                <td>arizold</td>
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td><img src="img/i-stroke.png" alt="i"></td>
                            </tr>
                            <!-- /.row -->
                            <tr class="row">
                                <td>arizold</td>
                                <td>2020-06-08 <br>
                                09:08:47</td>
                                <td>1 250.63 USD</td>
                                <td>Исходящий перевод</td>
                                <td>12 567.89 USD</td>
                                <td><img src="img/i-stroke.png" alt="i"></td>
                            </tr>
                            <!-- /.row -->
                        </tbody>
                    </table>
                </div>
                <button class="button panel__button">Показать еще</button> <!-- /.button panel__button -->
            </div>
            <!-- /.panel-body -->
        </main>
        <!-- /.main -->
    </div>
    <!-- /.container -->
<?php include 'footer.php'; ?>